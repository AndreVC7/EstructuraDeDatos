#pragma once
#include <iostream>
#include "Inter.h"
#include <string>

namespace Ejercicio10 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Inter In1;
	Inter In2;
	Inter In3;
	Inter In4;
	int pos=0;


	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtTamano1;
	private: System::Windows::Forms::Button^  btnTamano1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtTamano2;
	private: System::Windows::Forms::Button^  btnTamano2;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtVal1;
	private: System::Windows::Forms::TextBox^  txtVal2;
	private: System::Windows::Forms::Button^  btnVal1;
	private: System::Windows::Forms::Button^  btnVal2;
	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridView^  grilla2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  btnIntercalar;
	private: System::Windows::Forms::DataGridView^  grilla3;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtTamano1 = (gcnew System::Windows::Forms::TextBox());
			this->btnTamano1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtTamano2 = (gcnew System::Windows::Forms::TextBox());
			this->btnTamano2 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtVal1 = (gcnew System::Windows::Forms::TextBox());
			this->txtVal2 = (gcnew System::Windows::Forms::TextBox());
			this->btnVal1 = (gcnew System::Windows::Forms::Button());
			this->btnVal2 = (gcnew System::Windows::Forms::Button());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnIntercalar = (gcnew System::Windows::Forms::Button());
			this->grilla3 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(91, 23);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(17, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"A";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 55);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(60, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Tamano";
			// 
			// txtTamano1
			// 
			this->txtTamano1->Location = System::Drawing::Point(85, 52);
			this->txtTamano1->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtTamano1->Name = L"txtTamano1";
			this->txtTamano1->Size = System::Drawing::Size(132, 22);
			this->txtTamano1->TabIndex = 2;
			// 
			// btnTamano1
			// 
			this->btnTamano1->Location = System::Drawing::Point(47, 84);
			this->btnTamano1->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnTamano1->Name = L"btnTamano1";
			this->btnTamano1->Size = System::Drawing::Size(100, 28);
			this->btnTamano1->TabIndex = 3;
			this->btnTamano1->Text = L"Ingresar";
			this->btnTamano1->UseVisualStyleBackColor = true;
			this->btnTamano1->Click += gcnew System::EventHandler(this, &Form1::btnTamano1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(351, 23);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(17, 17);
			this->label3->TabIndex = 4;
			this->label3->Text = L"B";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(269, 55);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(60, 17);
			this->label4->TabIndex = 5;
			this->label4->Text = L"Tamano";
			// 
			// txtTamano2
			// 
			this->txtTamano2->Location = System::Drawing::Point(339, 52);
			this->txtTamano2->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtTamano2->Name = L"txtTamano2";
			this->txtTamano2->Size = System::Drawing::Size(132, 22);
			this->txtTamano2->TabIndex = 6;
			// 
			// btnTamano2
			// 
			this->btnTamano2->Location = System::Drawing::Point(311, 84);
			this->btnTamano2->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnTamano2->Name = L"btnTamano2";
			this->btnTamano2->Size = System::Drawing::Size(100, 28);
			this->btnTamano2->TabIndex = 7;
			this->btnTamano2->Text = L"Ingresar";
			this->btnTamano2->UseVisualStyleBackColor = true;
			this->btnTamano2->Click += gcnew System::EventHandler(this, &Form1::btnTamano2_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(16, 138);
			this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(41, 17);
			this->label5->TabIndex = 8;
			this->label5->Text = L"Valor";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(269, 138);
			this->label6->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(41, 17);
			this->label6->TabIndex = 9;
			this->label6->Text = L"Valor";
			// 
			// txtVal1
			// 
			this->txtVal1->Location = System::Drawing::Point(85, 134);
			this->txtVal1->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtVal1->Name = L"txtVal1";
			this->txtVal1->Size = System::Drawing::Size(132, 22);
			this->txtVal1->TabIndex = 10;
			// 
			// txtVal2
			// 
			this->txtVal2->Location = System::Drawing::Point(339, 134);
			this->txtVal2->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->txtVal2->Name = L"txtVal2";
			this->txtVal2->Size = System::Drawing::Size(132, 22);
			this->txtVal2->TabIndex = 11;
			// 
			// btnVal1
			// 
			this->btnVal1->Location = System::Drawing::Point(47, 166);
			this->btnVal1->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnVal1->Name = L"btnVal1";
			this->btnVal1->Size = System::Drawing::Size(100, 28);
			this->btnVal1->TabIndex = 12;
			this->btnVal1->Text = L"Ingresar";
			this->btnVal1->UseVisualStyleBackColor = true;
			this->btnVal1->Click += gcnew System::EventHandler(this, &Form1::btnVal1_Click);
			// 
			// btnVal2
			// 
			this->btnVal2->Location = System::Drawing::Point(311, 166);
			this->btnVal2->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnVal2->Name = L"btnVal2";
			this->btnVal2->Size = System::Drawing::Size(100, 28);
			this->btnVal2->TabIndex = 13;
			this->btnVal2->Text = L"Ingresar";
			this->btnVal2->UseVisualStyleBackColor = true;
			this->btnVal2->Click += gcnew System::EventHandler(this, &Form1::btnVal2_Click);
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla1->Location = System::Drawing::Point(11, 202);
			this->grilla1->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(191, 185);
			this->grilla1->TabIndex = 14;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grilla2->Location = System::Drawing::Point(273, 202);
			this->grilla2->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->grilla2->Name = L"grilla2";
			this->grilla2->Size = System::Drawing::Size(185, 196);
			this->grilla2->TabIndex = 15;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// btnIntercalar
			// 
			this->btnIntercalar->Location = System::Drawing::Point(637, 23);
			this->btnIntercalar->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->btnIntercalar->Name = L"btnIntercalar";
			this->btnIntercalar->Size = System::Drawing::Size(100, 28);
			this->btnIntercalar->TabIndex = 16;
			this->btnIntercalar->Text = L"Concatenar";
			this->btnIntercalar->UseVisualStyleBackColor = true;
			this->btnIntercalar->Click += gcnew System::EventHandler(this, &Form1::btnIntercalar_Click);
			// 
			// grilla3
			// 
			this->grilla3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->grilla3->Location = System::Drawing::Point(585, 59);
			this->grilla3->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->grilla3->Name = L"grilla3";
			this->grilla3->Size = System::Drawing::Size(187, 219);
			this->grilla3->TabIndex = 17;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Column3";
			this->Column3->Name = L"Column3";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(788, 503);
			this->Controls->Add(this->grilla3);
			this->Controls->Add(this->btnIntercalar);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->btnVal2);
			this->Controls->Add(this->btnVal1);
			this->Controls->Add(this->txtVal2);
			this->Controls->Add(this->txtVal1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->btnTamano2);
			this->Controls->Add(this->txtTamano2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnTamano1);
			this->Controls->Add(this->txtTamano1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnTamano1_Click(System::Object^  sender, System::EventArgs^  e) {
				 int Tam1;
				 Tam1=System::Convert::ToInt32(txtTamano1->Text);
				 In3.Set_tamano(Tam1);
				 In1.Set_tamano(Tam1);
				 grilla1->RowCount=In1.Get_tamano();
				 
				 pos=0;
			 }
private: System::Void btnTamano2_Click(System::Object^  sender, System::EventArgs^  e) {
				 int Tam2,Tam1;
				 Tam2=System::Convert::ToInt32(txtTamano2->Text);
				 Tam1=System::Convert::ToInt32(txtTamano1->Text);
				 In2.Set_tamano(Tam2);
				 In3.Set_tamano(Tam1+Tam2);
				
				 grilla2->RowCount=In2.Get_tamano();
				 pos=0;
		 }
private: System::Void btnVal1_Click(System::Object^  sender, System::EventArgs^  e) {
			 double elem1;
			 elem1=System::Convert::ToDouble(txtVal1->Text);
			
			 if(In1.Llenar(pos,elem1))
			 {	 In1.Set_vector(pos,elem1);
				 pos++;
				 grilla1->ColumnCount=1;
				 grilla1->ColumnCount=In1.Get_tamano();
				 double val1;
				 for(int i=0;i<In1.Get_tamano();i++)
				 {
					
					 val1=In1.Get_vector(i);
				
					 grilla1->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val1);
					 
					 
				 }
			 }
			 }
private: System::Void btnVal2_Click(System::Object^  sender, System::EventArgs^  e) {
			  double elem2;
			 elem2=System::Convert::ToDouble(txtVal2->Text);
			 if(In2.Llenar(pos,elem2))
			 { 
In2.Set_vector(pos,elem2);
			 	 pos++;
				 grilla2->ColumnCount=1;
				 grilla2->ColumnCount=In2.Get_tamano();
				 double val2;
				 for(int i=0;i<In2.Get_tamano();i++)
				 {
					 val2=In2.Get_vector(i);
					 grilla2->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val2);
					 }
			 }
		 }
private: System::Void btnIntercalar_Click(System::Object^  sender, System::EventArgs^  e) {
			int Tam1,Tam2,Tam3;
			Tam1=System::Convert::ToInt32(txtTamano1->Text);
			Tam2=System::Convert::ToInt32(txtTamano2->Text);
			Tam3=Tam1+Tam2;
			In3.Set_tamano(Tam3);
			grilla3->RowCount=In3.Get_tamano();
			In1.Ordenar(Tam1);
			In2.Ordenar(Tam2);
			
			for(int i=0;i<In1.Get_tamano();i++)
			{
				In3.Set_vector(i,In1.Get_vector(i));
			}
				for(int k=In1.Get_tamano();k<(In1.Get_tamano()+In2.Get_tamano());k++)
				{In3.Set_vector(k,In2.Get_vector(k-In1.Get_tamano()));
				}

			for(int i=0;i<In3.Get_tamano();i++)
			{
				grilla3->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(In3.Get_vector(i));
			}

			
		 }
};
}

