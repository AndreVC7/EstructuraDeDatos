#pragma once
#define N 20
#define M 40

class Inter
{
private:
	double vec[N];
	int tamano;
public:
	Inter(void);
	double Get_vector(int posicion);
	void Set_vector(int posicion, double elemento);
	int Get_tamano();
	void Set_tamano(int tam);
	bool LlenoVector();
	bool VacioVector();
	bool Llenar(int poicion ,double elemento);
	Inter Concatenar(Inter vec1, Inter vec2);
	void Ordenar(int tam);
};

