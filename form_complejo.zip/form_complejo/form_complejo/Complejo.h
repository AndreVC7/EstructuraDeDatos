#pragma once
class CComplejo
{
private:
	double real, imag;

public:
	CComplejo(void);
	void Set_real(double r);
	void Set_imag(double i);
	double Get_real();
	double Get_imag();
	void suma(CComplejo a, CComplejo b);
};

