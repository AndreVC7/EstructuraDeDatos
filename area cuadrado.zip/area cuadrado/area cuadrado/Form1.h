#pragma once

namespace areacuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btbcalcular;
	protected: 

	protected: 
	private: System::Windows::Forms::Label^  lado;
	private: System::Windows::Forms::Label^  area;
	private: System::Windows::Forms::TextBox^  txtlado;
	private: System::Windows::Forms::TextBox^  txtarea;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btbcalcular = (gcnew System::Windows::Forms::Button());
			this->lado = (gcnew System::Windows::Forms::Label());
			this->area = (gcnew System::Windows::Forms::Label());
			this->txtlado = (gcnew System::Windows::Forms::TextBox());
			this->txtarea = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// btbcalcular
			// 
			this->btbcalcular->Location = System::Drawing::Point(105, 205);
			this->btbcalcular->Name = L"btbcalcular";
			this->btbcalcular->Size = System::Drawing::Size(76, 32);
			this->btbcalcular->TabIndex = 0;
			this->btbcalcular->Text = L"Calcular";
			this->btbcalcular->UseVisualStyleBackColor = true;
			this->btbcalcular->Click += gcnew System::EventHandler(this, &Form1::btbcalcular_Click);
			// 
			// lado
			// 
			this->lado->AutoSize = true;
			this->lado->Location = System::Drawing::Point(42, 27);
			this->lado->Name = L"lado";
			this->lado->Size = System::Drawing::Size(31, 13);
			this->lado->TabIndex = 1;
			this->lado->Text = L"Lado";
			this->lado->Click += gcnew System::EventHandler(this, &Form1::lado_Click);
			// 
			// area
			// 
			this->area->AutoSize = true;
			this->area->Location = System::Drawing::Point(41, 83);
			this->area->Name = L"area";
			this->area->Size = System::Drawing::Size(29, 13);
			this->area->TabIndex = 2;
			this->area->Text = L"Area";
			// 
			// txtlado
			// 
			this->txtlado->Location = System::Drawing::Point(139, 29);
			this->txtlado->Name = L"txtlado";
			this->txtlado->Size = System::Drawing::Size(107, 20);
			this->txtlado->TabIndex = 3;
			this->txtlado->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// txtarea
			// 
			this->txtarea->Location = System::Drawing::Point(138, 80);
			this->txtarea->Name = L"txtarea";
			this->txtarea->Size = System::Drawing::Size(107, 20);
			this->txtarea->TabIndex = 4;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 262);
			this->Controls->Add(this->txtarea);
			this->Controls->Add(this->txtlado);
			this->Controls->Add(this->area);
			this->Controls->Add(this->lado);
			this->Controls->Add(this->btbcalcular);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {

			 }
private: System::Void btbcalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 	int lado, area;
		lado = System::Convert::ToInt32(txtlado->Text);
		area = lado * lado;
		txtarea->Text = area.ToString();
		 }
private: System::Void lado_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

