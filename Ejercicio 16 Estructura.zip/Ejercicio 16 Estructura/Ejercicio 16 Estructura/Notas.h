#pragma once
using namespace std;

class Notas
{
private:
	double nota;
public:
	Notas(void);
	void setNotas(double);
	double getNotas();
};

