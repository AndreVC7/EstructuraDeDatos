#pragma once
#include <string>
using namespace std;

class Nombres
{
private:
	string nombre;
public:
	Nombres(void);
	void setNombre(string);
	string getNombre();
};