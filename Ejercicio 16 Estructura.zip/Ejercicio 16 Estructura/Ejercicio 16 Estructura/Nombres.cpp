#include "StdAfx.h"
#include "Nombres.h"


Nombres::Nombres(void)
{
	nombre = "";
}

void Nombres::setNombre(string _nombre){
	nombre  = _nombre;
}

string Nombres::getNombre(){
	return nombre;
}
