#pragma once
#include "Vector.h"
#include <msclr\marshal_cppstd.h>
namespace Ejercicio16Estructura {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>

	Vector datosAlumnos;

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblTam;
	protected: 
	private: System::Windows::Forms::Label^  lblNombre;
	private: System::Windows::Forms::Label^  lblNota;
	private: System::Windows::Forms::TextBox^  tbTam;
	private: System::Windows::Forms::TextBox^  tbNombre;
	private: System::Windows::Forms::TextBox^  tbNota;
	private: System::Windows::Forms::Button^  btnOrdenar;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnActualizar;
	private: System::Windows::Forms::DataGridView^  dgvAlumnos;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  alumno;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  nota;
	private: System::Windows::Forms::TextBox^  tbPos;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblTam = (gcnew System::Windows::Forms::Label());
			this->lblNombre = (gcnew System::Windows::Forms::Label());
			this->lblNota = (gcnew System::Windows::Forms::Label());
			this->tbTam = (gcnew System::Windows::Forms::TextBox());
			this->tbNombre = (gcnew System::Windows::Forms::TextBox());
			this->tbNota = (gcnew System::Windows::Forms::TextBox());
			this->btnOrdenar = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnActualizar = (gcnew System::Windows::Forms::Button());
			this->dgvAlumnos = (gcnew System::Windows::Forms::DataGridView());
			this->alumno = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->nota = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->tbPos = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvAlumnos))->BeginInit();
			this->SuspendLayout();
			// 
			// lblTam
			// 
			this->lblTam->AutoSize = true;
			this->lblTam->Location = System::Drawing::Point(17, 26);
			this->lblTam->Name = L"lblTam";
			this->lblTam->Size = System::Drawing::Size(60, 17);
			this->lblTam->TabIndex = 0;
			this->lblTam->Text = L"Tama�o";
			// 
			// lblNombre
			// 
			this->lblNombre->AutoSize = true;
			this->lblNombre->Location = System::Drawing::Point(17, 86);
			this->lblNombre->Name = L"lblNombre";
			this->lblNombre->Size = System::Drawing::Size(62, 17);
			this->lblNombre->TabIndex = 1;
			this->lblNombre->Text = L"Nombre:";
			// 
			// lblNota
			// 
			this->lblNota->AutoSize = true;
			this->lblNota->Location = System::Drawing::Point(17, 141);
			this->lblNota->Name = L"lblNota";
			this->lblNota->Size = System::Drawing::Size(42, 17);
			this->lblNota->TabIndex = 2;
			this->lblNota->Text = L"Nota:";
			// 
			// tbTam
			// 
			this->tbTam->Location = System::Drawing::Point(110, 26);
			this->tbTam->Name = L"tbTam";
			this->tbTam->Size = System::Drawing::Size(100, 22);
			this->tbTam->TabIndex = 3;
			// 
			// tbNombre
			// 
			this->tbNombre->Location = System::Drawing::Point(110, 83);
			this->tbNombre->Name = L"tbNombre";
			this->tbNombre->Size = System::Drawing::Size(100, 22);
			this->tbNombre->TabIndex = 4;
			// 
			// tbNota
			// 
			this->tbNota->Location = System::Drawing::Point(110, 141);
			this->tbNota->Name = L"tbNota";
			this->tbNota->Size = System::Drawing::Size(100, 22);
			this->tbNota->TabIndex = 5;
			// 
			// btnOrdenar
			// 
			this->btnOrdenar->Location = System::Drawing::Point(333, 373);
			this->btnOrdenar->Name = L"btnOrdenar";
			this->btnOrdenar->Size = System::Drawing::Size(102, 33);
			this->btnOrdenar->TabIndex = 6;
			this->btnOrdenar->Text = L"Mostrar";
			this->btnOrdenar->UseVisualStyleBackColor = true;
			this->btnOrdenar->Click += gcnew System::EventHandler(this, &Form1::btnOrdenar_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(225, 129);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(100, 34);
			this->btnIngresar->TabIndex = 7;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnActualizar
			// 
			this->btnActualizar->Location = System::Drawing::Point(225, 26);
			this->btnActualizar->Name = L"btnActualizar";
			this->btnActualizar->Size = System::Drawing::Size(102, 34);
			this->btnActualizar->TabIndex = 8;
			this->btnActualizar->Text = L"Actualizar";
			this->btnActualizar->UseVisualStyleBackColor = true;
			this->btnActualizar->Click += gcnew System::EventHandler(this, &Form1::btnActualizar_Click);
			// 
			// dgvAlumnos
			// 
			this->dgvAlumnos->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dgvAlumnos->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->alumno, this->nota});
			this->dgvAlumnos->Location = System::Drawing::Point(25, 243);
			this->dgvAlumnos->Name = L"dgvAlumnos";
			this->dgvAlumnos->RowTemplate->Height = 24;
			this->dgvAlumnos->Size = System::Drawing::Size(302, 163);
			this->dgvAlumnos->TabIndex = 9;
			// 
			// alumno
			// 
			this->alumno->HeaderText = L"Alumno";
			this->alumno->Name = L"alumno";
			// 
			// nota
			// 
			this->nota->HeaderText = L"Nota";
			this->nota->Name = L"nota";
			// 
			// tbPos
			// 
			this->tbPos->Location = System::Drawing::Point(110, 170);
			this->tbPos->Name = L"tbPos";
			this->tbPos->Size = System::Drawing::Size(100, 22);
			this->tbPos->TabIndex = 10;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(502, 425);
			this->Controls->Add(this->tbPos);
			this->Controls->Add(this->dgvAlumnos);
			this->Controls->Add(this->btnActualizar);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnOrdenar);
			this->Controls->Add(this->tbNota);
			this->Controls->Add(this->tbNombre);
			this->Controls->Add(this->tbTam);
			this->Controls->Add(this->lblNota);
			this->Controls->Add(this->lblNombre);
			this->Controls->Add(this->lblTam);
			this->Name = L"Form1";
			this->Text = L"Form1";
			//this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dgvAlumnos))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnActualizar_Click(System::Object^  sender, System::EventArgs^  e) {
				 datosAlumnos.setTam(Convert::ToInt32(tbTam -> Text);
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			datosAlumnos.setNombre(Convert::ToInt32(tbPos->Text), Convert::ToString(tbNombre->Text));
			datosAlumnos.setNombre(Convert::ToInt32(tbPos->Text), Convert::ToDouble(tbNota->Text));
		 }
private: System::Void btnOrdenar_Click(System::Object^  sender, System::EventArgs^  e) {
			 for(int i=0; i<datosAlumnos.getTam(); i++){
				dgvAlumnos->Rows[i]->Cells[0]->Value = marshal_as<String^>(datosAlumnos.getNombre(i));
				dgvAlumnos->Rows[i]->Cells[1]->Value = datosAlumnos.getNota(i);
			 }
		 }
};
}

