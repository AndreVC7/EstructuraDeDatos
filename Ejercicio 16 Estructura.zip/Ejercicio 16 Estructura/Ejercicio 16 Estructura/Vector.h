#pragma once
#include "Nombres.h"
#include "Notas.h"

class Vector
{
private:
	int tam;
	Nombres arrNombres[20]; //GUARDAR NOMBRES
	Notas arrNotas[20]; //GUARDAR NOTAS
public:
	Vector(void);
	//SET METHODS
	void setTam(int);
	void setNombre(int, string);
	void setNota(int, double);
	//GET METHODS
	int getTam();
	string getNombre(int);
	double getNota(int);
};

