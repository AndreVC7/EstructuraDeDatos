#include "StdAfx.h"
#include "Notas.h"


Notas::Notas(void)
{
	nota = 0;
}

void Notas::setNotas(double _nota){
	nota = _nota;
}

double Notas::getNotas(){
	return nota;
}