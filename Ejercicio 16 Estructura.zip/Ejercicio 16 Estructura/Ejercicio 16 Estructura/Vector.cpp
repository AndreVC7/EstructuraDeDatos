#include "StdAfx.h"
#include "Vector.h"


Vector::Vector(void)
{
	tam = 0;
	for(int i=0; i<20; i++){
		arrNombres[i].setNombre("");
		arrNotas[i].setNotas(0.0);
	}
}
//SET METHODS
void Vector::setTam(int _tam){
	tam = _tam;
}
void Vector::setNombre(int pos, string _nombre){
	arrNombres[pos].setNombre(_nombre);
}
void Vector::setNota(int pos, double _nota){
	arrNotas[pos].setNotas(_nota);
}
//GET METHODS
int Vector::getTam(){
	return tam;
}
string Vector::getNombre(int pos){
	return arrNombres[pos].getNombre();
}
double Vector::getNota(int pos){
	return arrNotas[pos].getNotas();
}

