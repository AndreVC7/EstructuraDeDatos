#include "StdAfx.h"
#include "Cuenta.h"


Cuenta::Cuenta(void)
{
}

void Cuenta::Set_nombre(string nom){
	nombre=nom;
}

void Cuenta::Set_cuenta(string cue){
	cuenta=cue;
}

void Cuenta::Set_tipodeinteres(double tipo){
	tipodeinteres=tipo;
}

string Cuenta::Get_nombre(){
	return nombre;
}

string Cuenta::Get_cuenta(){
	return cuenta;
}

double Cuenta::Get_tipodeinteres(){
	return tipodeinteres;
}

double Cuenta::estado(){
	return saldo;
}

void Cuenta::reintegro(double cantidad){
	saldo=saldo-cantidad;
}

void Cuenta::ingreso(double cantidad){
	saldo=saldo+cantidad;
}
