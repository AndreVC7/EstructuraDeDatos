#pragma once

namespace CuentaBancaria {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtcuenta;
	private: System::Windows::Forms::TextBox^  txtnombre;
	private: System::Windows::Forms::TextBox^  txttipo;
	private: System::Windows::Forms::TextBox^  txtsaldo;
	private: System::Windows::Forms::Button^  calcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtcuenta = (gcnew System::Windows::Forms::TextBox());
			this->txtnombre = (gcnew System::Windows::Forms::TextBox());
			this->txttipo = (gcnew System::Windows::Forms::TextBox());
			this->txtsaldo = (gcnew System::Windows::Forms::TextBox());
			this->calcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(25, 42);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(53, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Cuenta";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(23, 104);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(58, 17);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Nombre";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(23, 162);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(103, 17);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Tipo de Interes";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(23, 222);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(44, 17);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Saldo";
			// 
			// txtcuenta
			// 
			this->txtcuenta->Location = System::Drawing::Point(294, 44);
			this->txtcuenta->Name = L"txtcuenta";
			this->txtcuenta->Size = System::Drawing::Size(135, 22);
			this->txtcuenta->TabIndex = 4;
			// 
			// txtnombre
			// 
			this->txtnombre->Location = System::Drawing::Point(289, 100);
			this->txtnombre->Name = L"txtnombre";
			this->txtnombre->Size = System::Drawing::Size(139, 22);
			this->txtnombre->TabIndex = 5;
			// 
			// txttipo
			// 
			this->txttipo->Location = System::Drawing::Point(288, 156);
			this->txttipo->Name = L"txttipo";
			this->txttipo->Size = System::Drawing::Size(140, 22);
			this->txttipo->TabIndex = 6;
			// 
			// txtsaldo
			// 
			this->txtsaldo->Location = System::Drawing::Point(289, 220);
			this->txtsaldo->Name = L"txtsaldo";
			this->txtsaldo->Size = System::Drawing::Size(139, 22);
			this->txtsaldo->TabIndex = 7;
			// 
			// calcular
			// 
			this->calcular->Location = System::Drawing::Point(145, 383);
			this->calcular->Name = L"calcular";
			this->calcular->Size = System::Drawing::Size(225, 28);
			this->calcular->TabIndex = 8;
			this->calcular->Text = L"Calcular";
			this->calcular->UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(505, 485);
			this->Controls->Add(this->calcular);
			this->Controls->Add(this->txtsaldo);
			this->Controls->Add(this->txttipo);
			this->Controls->Add(this->txtnombre);
			this->Controls->Add(this->txtcuenta);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}

