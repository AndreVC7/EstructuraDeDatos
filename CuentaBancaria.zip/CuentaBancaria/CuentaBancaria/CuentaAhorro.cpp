#include "StdAfx.h"
#include "CuentaAhorro.h"
#include "Cuenta.h"


CuentaAhorro::CuentaAhorro(void)
{
}

void CuentaAhorro::Set_cuotamantenimiento(double cantidad){
	cuotamantenimiento=cantidad;
}

double CuentaAhorro::Get_cuotamantenimiento(){
	return cuotamantenimiento;
}

void CuentaAhorro::reintegro(double cantidad){
	saldo=saldo-cantidad;
}
