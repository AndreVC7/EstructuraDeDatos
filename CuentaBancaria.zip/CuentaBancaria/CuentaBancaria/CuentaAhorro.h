#pragma once
#include "Cuenta.h"
#include "string.h"
#include "iostream"
using namespace std;

class CuentaAhorro:public Cuenta
{
private:
	double cuotamantenimiento;
public:
	CuentaAhorro(void);
	void Set_cuotamantenimiento(double cantidad);
	double Get_cuotamantenimiento();
	void reintegro(double cantidad);
};

