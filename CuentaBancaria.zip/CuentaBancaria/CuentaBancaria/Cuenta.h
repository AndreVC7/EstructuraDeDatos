#pragma once
#include "iostream"
#include "string.h"
using namespace std;
class Cuenta
{
private:
	double saldo;
	double tipodeinteres;
	string nombre;
	string cuenta;

public:
	Cuenta(void);
	void Set_nombre(string nom);
	void Set_cuenta(string cue);
	void Set_tipodeinteres(double tipo);
	string Get_nombre();
	string Get_cuenta();
	double Get_tipodeinteres();
	double estado();
	void reintegro(double cantidad);
	void ingreso(double cantidad);
};

